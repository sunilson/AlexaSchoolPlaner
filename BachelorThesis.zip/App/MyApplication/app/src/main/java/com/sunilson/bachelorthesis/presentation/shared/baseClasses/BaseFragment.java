package com.sunilson.bachelorthesis.presentation.shared.baseClasses;

import android.support.v4.app.Fragment;

/**
 * Created by linus_000 on 28.11.2017.
 */

public abstract class BaseFragment extends Fragment {

}
