package com.sunilson.bachelorthesis.data.repository.BodyModels;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Created by linus on 09.02.2018.
 */

@AllArgsConstructor
public class UrlForPostBody {
    @Getter
    private String url;
    @Getter
    private Integer type;
}
