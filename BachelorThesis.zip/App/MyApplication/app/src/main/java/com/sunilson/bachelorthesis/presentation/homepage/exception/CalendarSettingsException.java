package com.sunilson.bachelorthesis.presentation.homepage.exception;

/**
 * @author Linus Weiss
 */

public class CalendarSettingsException extends Exception {
    public CalendarSettingsException(String message){
        super(message);
    }
}
