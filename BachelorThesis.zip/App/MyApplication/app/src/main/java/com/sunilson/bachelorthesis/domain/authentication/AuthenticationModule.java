package com.sunilson.bachelorthesis.domain.authentication;

import dagger.Module;

/**
 * @author Linus Weiss
 */

@Module
public class AuthenticationModule { }
