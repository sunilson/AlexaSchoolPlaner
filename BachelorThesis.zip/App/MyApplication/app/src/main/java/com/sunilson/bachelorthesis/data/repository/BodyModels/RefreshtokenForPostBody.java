package com.sunilson.bachelorthesis.data.repository.BodyModels;

import lombok.AllArgsConstructor;

/**
 * @author Linus Weiss
 */

@AllArgsConstructor
public class RefreshtokenForPostBody {
    String refresh_token;
}
