package com.sunilson.bachelorthesis.domain.authentication.mappers;

/**
 * @author Linus Weiss
 */

public class UserEntityToTokensMapper {
}
