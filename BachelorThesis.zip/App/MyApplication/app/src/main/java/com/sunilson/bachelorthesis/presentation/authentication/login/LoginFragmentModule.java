package com.sunilson.bachelorthesis.presentation.authentication.login;

import dagger.Module;

/**
 * Created by linus_000 on 02.12.2017.
 */

@Module
public class LoginFragmentModule {
}
