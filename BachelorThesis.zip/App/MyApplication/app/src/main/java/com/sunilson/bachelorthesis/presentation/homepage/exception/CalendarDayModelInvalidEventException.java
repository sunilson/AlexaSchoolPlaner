package com.sunilson.bachelorthesis.presentation.homepage.exception;

/**
 * @author Linus Weiss
 */

public class CalendarDayModelInvalidEventException extends Exception {

    public CalendarDayModelInvalidEventException(String message) {
        super(message);
    }

}
