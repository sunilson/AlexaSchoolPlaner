package com.sunilson.bachelorthesis.presentation.authentication.dependencyInjection;

import dagger.Module;

/**
 * @author Linus Weiss
 */

@Module
public class AuthenticationModule {
}
