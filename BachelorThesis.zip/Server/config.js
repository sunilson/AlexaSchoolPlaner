module.exports = {
    mongoDBURL: "mongodb://sunilson:Ingo-Gasser12@ds113586.mlab.com:13586/heroku_h0d69mkh",
    jwtSecret: "WmI6293zsh9MEIolmy7lMqigFHy7BMgv",
    jwtRefreshSecret: "HjVWnid7FE3sgBB4xPWMK6uZXR08uh45",
    jwtSession: {
        session: false
    },
    mailGunKey: "key-3535e50d7799f86659911fc6aad799bd",
    mailGunDomain: "sunilson.com",
    algolia: {
        appId: "E8K8UVW4LL",
        apiKey: "4c873f8da1ac0956e272cf72ffbe8f7f"
    },
    algoliaIndexSettings: {
        'searchableAttributes': [
            'description',
            'summary',
            'location'
        ],
        'attributesForFaceting': [
            'author',
            'eventID',
            'objectID'
        ]
    },
    importToken: "abc123",
    alexaSecret: "abc123"
};